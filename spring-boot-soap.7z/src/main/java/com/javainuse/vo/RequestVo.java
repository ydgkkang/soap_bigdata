package com.javainuse.vo;

public class RequestVo {
    String users;

    public String getUsers() {
        return users;
    }

    public void setUsers(String users) {
        this.users = users;
    }
}
