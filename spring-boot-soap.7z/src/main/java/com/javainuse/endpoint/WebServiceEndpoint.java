package com.javainuse.endpoint;

import com.javainuse.InputSOATest;
import com.javainuse.ObjectFactory;
import com.javainuse.OutputSOATest;
import com.javainuse.mapper.RequestMapper;
import com.sun.javafx.collections.MappingChange;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import javax.sql.DataSource;
import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Endpoint
@Service
@SpringBootApplication
@Transactional(rollbackFor = RuntimeException.class)
public class WebServiceEndpoint {


	private static final String NAMESPACE_URI = "http://javainuse.com";


	@Autowired
	private RequestMapper requestMapper;

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private TransactionTemplate transactionTemplate;

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "inputSOATest")
	@ResponsePayload

	public OutputSOATest endpoint (@RequestPayload InputSOATest request) throws Exception {


		ObjectFactory factory = new ObjectFactory();
		OutputSOATest response = factory.createOutputSOATest();

		int updateUserCnt = 0;
		int updateDeptNmCnt = 0;
		int updatePdeptNmCnt = 0;
		int updateCorpNmCnt = 0;
		int updateJobNmCnt = 0;
		int updateJobGrdNmCnt = 0;
	try{


		JAXBElement<InputSOATest> jaxb = new JAXBElement( new QName(InputSOATest.class.getSimpleName()), InputSOATest.class, request);
		int size = jaxb.getValue().getRequestSet().getValue().getUserInfo().size();
		String outputString = "RESULT :: " + jaxb.getValue().getRequestSet().getValue().getUserInfo().size();

		//테스트 후 삭제 예정
		JSONArray jsonArray = new JSONArray();
		JSONArray objectJaxb = new JSONArray();
		JSONObject insertUser = new JSONObject();
		JSONObject insertDeptNm = new JSONObject();
		JSONObject insertPdeptNm = new JSONObject();
		JSONObject insertCorpNm = new JSONObject();
		JSONObject insertJobNm = new JSONObject();
		JSONObject insertJobGrdNm = new JSONObject();


		List<Map> insertUserList = new ArrayList<Map>();
		List<Map> insertDeptNmList = new ArrayList<Map>();
		List<Map> insertPdeptNmList = new ArrayList<Map>();
		List<Map> insertCorpNmList = new ArrayList<Map>();
		List<Map> insertJobNmList = new ArrayList<Map>();
		List<Map> insertJobGrdNmList = new ArrayList<Map>();


		if (size > 0) {
			for (int i = 0; i < jaxb.getValue().getRequestSet().getValue().getUserInfo().size(); i++) {
				HashMap<String, Object> insertUserMap = new HashMap<String, Object>();
				logger.info("Array to xml >> JsonArray File Create "+ jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i) );
				//create file
				jsonArray.put(jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).toString());
				objectJaxb.put(jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i));

				logger.info("Json Array >>"+ jsonArray);

				insertUser.put("EMPID_"+i, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getEMPID().toString());
				insertUser.put("SINGLEID_"+i, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getSINGLEID().toString());
				insertUser.put("EPID_"+i, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getEPID().toString());
				insertUser.put("NAME_"+i, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getNAME().toString());
				insertUser.put("ENGNAME_"+i, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getENGNAME().toString());
				insertUser.put("EMPTYPE_"+i, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getEMPTYPE().toString());
				insertUser.put("LVABSENCE_"+i, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getLVABSENCE().toString());
				insertUser.put("RETIRE_"+i, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getRETIRE().toString());
				insertUser.put("EMAIL_"+i, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getEMAIL().toString());
				insertUser.put("TELNUM_"+i, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getTELNUM().toString());
				insertUser.put("MBPHONE_"+i, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getMBPHONE().toString());
				insertUser.put("BSCADDR_"+i, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getBSCADDR().toString());
				insertUser.put("ZZBUKRS_"+i, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getZZBUKRS().toString());

				insertUserMap.put("EMPID", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getEMPID().toString());
				insertUserMap.put("SINGLEID", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getSINGLEID().toString());
				insertUserMap.put("EPID", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getEPID().toString());
				insertUserMap.put("NAME", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getNAME().toString());
				insertUserMap.put("ENGNAME", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getENGNAME().toString());
				insertUserMap.put("EMPTYPE", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getEMPTYPE().toString());
				insertUserMap.put("LVABSENCE", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getLVABSENCE().toString());
				insertUserMap.put("RETIRE", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getRETIRE().toString());
				insertUserMap.put("EMAIL", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getEMAIL().toString());
				insertUserMap.put("TELNUM", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getTELNUM().toString());
				insertUserMap.put("MBPHONE", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getMBPHONE().toString());
				insertUserMap.put("BSCADDR", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getBSCADDR().toString());
				insertUserMap.put("ZZBUKRS", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getZZBUKRS().toString());

				insertUserList.add(insertUserMap);
				//TABLE DEPTNM
				for(int j = 0; j < jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getDEPTNM().size(); j++ ) {
					HashMap<String, Object> insertDeptNmMap = new HashMap<String, Object>();
					logger.info("DEPTNM TABLE:: "+i + j);
					insertDeptNm.put("SPRAS_"+i+j, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getDEPTNM().get(j).getSPRAS().toString());
					insertDeptNm.put("DEPTNM_"+i+j, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getDEPTNM().get(j).getDEPTNM().toString());
					insertDeptNmMap.put("SPRAS",jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getDEPTNM().get(j).getSPRAS().toString());
					insertDeptNmMap.put("DEPTNM", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getDEPTNM().get(j).getDEPTNM().toString());
					insertDeptNmList.add(insertDeptNmMap);
				}

				//TABLE PDEPTNM
				for(int k = 0; k < jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getPDEPTNM().size(); k++ ) {
					HashMap<String, Object> insertPdeptNmMap = new HashMap<String, Object>();
					logger.info("PDEPTNM TABLE:: " + k);
					insertPdeptNm.put("SPRAS_"+i+k, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getPDEPTNM().get(k).getSPRAS().toString());
					insertPdeptNm.put("PDEPTNM_"+i+k, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getPDEPTNM().get(k).getPDEPTNM().toString());
					insertPdeptNmMap.put("SPRAS", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getPDEPTNM().get(k).getSPRAS().toString());
					insertPdeptNmMap.put("PDEPTNM", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getPDEPTNM().get(k).getPDEPTNM().toString());
					insertPdeptNmList.add(insertPdeptNmMap);
				}

				//CORPNM TABLE
				for(int m = 0; m < jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getCORPNM().size(); m++ ) {
					HashMap<String, Object> insertCorpNmMap = new HashMap<String, Object>();
					logger.info("CORPNM TABLE:: "+i + m);
					insertCorpNm.put("SPRAS_"+i+m, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getCORPNM().get(m).getSPRAS().toString());
					insertCorpNm.put("CORPNM_"+i+m, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getCORPNM().get(m).getCORPNM().toString());
					insertCorpNmMap.put("SPRAS", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getCORPNM().get(m).getSPRAS().toString());
					insertCorpNmMap.put("CORPNM", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getCORPNM().get(m).getCORPNM().toString());
					insertCorpNmList.add(insertCorpNmMap);
				}

				//JOBNM TABLE
				for(int v = 0; v < jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getJOBNM().size(); v++ ) {
					HashMap<String, Object> insertJobNmMap = new HashMap<String, Object>();
					logger.info("JOBNM TABLE:: "+i + v);
					logger.info("JOBNM TABLE:: "+i + v+ jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getJOBNM().get(v).getSPRAS().toString()) ;
					logger.info("JOBNM TABLE:: "+i + v + jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getJOBNM().get(v).getJOBNM().toString());
					insertJobNm.put("SPRAS"+i+v, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getJOBNM().get(v).getSPRAS().toString());
					insertJobNm.put("JOBNM"+i+v, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getJOBNM().get(v).getJOBNM().toString());
					insertJobNmMap.put("SPRAS", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getJOBNM().get(v).getSPRAS().toString());
					insertJobNmMap.put("JOBNM", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getJOBNM().get(v).getJOBNM().toString());
					insertJobNmList.add(insertJobNmMap);
				}

				//JOBGRDNM TABLE
				for(int z = 0; z < jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getJOBGRDNM().size(); z++ ) {
					HashMap<String, Object> insertJobGrdNmMap = new HashMap<String, Object>();
					logger.info("JOBGRDNM TABLE :: "+i + z);
					insertJobGrdNm.put("SPRAS_"+i+z, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getJOBGRDNM().get(z).getSPRAS().toString());
					insertJobGrdNm.put("JOBGRDNM_"+i+z, jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getJOBGRDNM().get(z).getJOBGRDNM().toString());
					insertJobGrdNmMap.put("SPRAS", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getJOBGRDNM().get(z).getSPRAS().toString());
					insertJobGrdNmMap.put("JOBGRDNM", jaxb.getValue().getRequestSet().getValue().getUserInfo().get(i).getJOBGRDNM().get(z).getJOBGRDNM().toString());
					insertJobGrdNmList.add(insertJobGrdNmMap);
				}


			}

			//DATABASE INSERT
			updateUserCnt = requestMapper.updateUser(insertUserList);
			if(updateUserCnt == 1) {
				updateDeptNmCnt = requestMapper.updateDeptNm(insertDeptNmList);
				updatePdeptNmCnt = requestMapper.updatePdeptNm(insertPdeptNmList);
				updateCorpNmCnt = requestMapper.updateCorpNm(insertCorpNmList);
				updateJobNmCnt = requestMapper.updateJobNm(insertJobNmList);
				updateJobGrdNmCnt = requestMapper.updateJobGrdNm(insertJobGrdNmList);
			}

		}
		outputString += "WRITE FILE CNT >> ";
		outputString += "updateUserCnt : "+updateUserCnt + "/ updateDeptNmCnt:" +updateDeptNmCnt +"/ updatePdeptNmCnt:" +updatePdeptNmCnt +
				"/ updateCorpNmCnt:" +updateCorpNmCnt +"/ updateJobNmCnt:" +updateJobNmCnt+"/ updateJobGrdNmCnt:" +updateJobGrdNmCnt;



		FileWriter file = new FileWriter("./soapTest.json");
		file.write(insertUser.toString());
		file.write(insertDeptNm.toString());
		file.write(insertPdeptNm.toString());
		file.write(insertCorpNm.toString());
		file.write(insertJobNm.toString());
		file.write(insertJobGrdNm.toString());
		file.write(outputString);
		file.flush();
		file.close();

		logger.info("insertUser"+ insertUser.toString());
		logger.info("insertDeptNm"+ insertDeptNm.toString());
		logger.info("insertPdeptNm"+ insertPdeptNm.toString());
		logger.info("insertCorpNm"+ insertCorpNm.toString());
		logger.info("insertJobNm"+ insertJobNm.toString());
		logger.info("insertJobGrdNm"+ insertJobGrdNm.toString());

		response.setResult(outputString);

	}catch (Exception e){
		logger.info("FAILED ");
		e.printStackTrace();
	}finally {
		logger.info("SUCCESS ");
		return response;

	}

	}
}

