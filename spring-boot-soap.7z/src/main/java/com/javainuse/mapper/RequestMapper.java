package com.javainuse.mapper;

import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

@MapperScan
public interface RequestMapper {
	/* DB Select  */

	public int updateUser(List<Map> updateUserList) throws Exception;

	public int updateDeptNm(List<Map> updateDeptNmList) throws Exception;

	public int updatePdeptNm(List<Map> updatePdeptNmList) throws Exception;

	public int updateCorpNm(List<Map> updateCorpNmList) throws Exception;

	public int updateJobNm(List<Map> updateJobNmList) throws Exception;

	public int updateJobGrdNm(List<Map> updateJobGrdNmList) throws Exception;
}

